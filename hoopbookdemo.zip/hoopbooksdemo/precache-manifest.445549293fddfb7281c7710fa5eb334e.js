self.__precacheManifest = [
  {
    "revision": "310509c95512893dc661bd3a6b0d2a5d",
    "url": "/hoopbooks/static/media/sidebar-2.310509c9.jpg"
  },
  {
    "revision": "9b672536575fd84f92067d9f6b04664f",
    "url": "/hoopbooks/static/media/reactlogo.9b672536.png"
  },
  {
    "revision": "027734bb84143bd34c0e",
    "url": "/hoopbooks/static/js/runtime~main.027734bb.js"
  },
  {
    "revision": "0cdee1a33b1bc73bab2b",
    "url": "/hoopbooks/static/js/main.0cdee1a3.chunk.js"
  },
  {
    "revision": "b4c4a3192b20fc80585b",
    "url": "/hoopbooks/static/js/2.b4c4a319.chunk.js"
  },
  {
    "revision": "0cdee1a33b1bc73bab2b",
    "url": "/hoopbooks/static/css/main.02c053ea.chunk.css"
  },
  {
    "revision": "b4c4a3192b20fc80585b",
    "url": "/hoopbooks/static/css/2.ed13fd3f.chunk.css"
  },
  {
    "revision": "db965e0c9a86bd08eb086f33ebf96644",
    "url": "/hoopbooks/index.html"
  }
];